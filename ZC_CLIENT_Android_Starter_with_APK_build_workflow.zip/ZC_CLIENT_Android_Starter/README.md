# ZC CLIENT Android project starter

Android application project configured for Android 9+ (minSdk 28) with a version selector, memory setting UI, and performance preset selector.

## Important
This is **not yet a functional Minecraft launcher**. The Launch button is a placeholder because a compatible Java runtime and game-launching engine have not been integrated. No Minecraft game files are bundled.

## Build an APK
1. Open this folder in Android Studio on a computer.
2. Use JDK 17 and allow Gradle sync.
3. Choose Build > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`
5. Copy that APK to the Vivo phone and install it.

If you only have your phone, a cloud Android build environment may be needed; compatibility depends on the service.
