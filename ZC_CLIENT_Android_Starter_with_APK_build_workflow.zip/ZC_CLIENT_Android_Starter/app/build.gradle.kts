plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.zcclient.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.zcclient.launcher"
        minSdk = 28
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}
