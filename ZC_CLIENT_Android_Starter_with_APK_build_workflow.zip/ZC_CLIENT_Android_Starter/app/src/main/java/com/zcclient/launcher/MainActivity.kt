package com.zcclient.launcher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 30)
    private val panel = Color.rgb(20, 29, 51)
    private val cyan = Color.rgb(42, 211, 238)
    private lateinit var version: Spinner
    private lateinit var ramLabel: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
        }
        scroll.addView(layout)
        setContentView(scroll)

        layout.addView(TextView(this).apply {
            text = "ZC CLIENT"
            textSize = 30f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, matchWrap())
        layout.addView(label("MINECRAFT JAVA • MOBILE LAUNCHER STARTER"), matchWrap())
        layout.addView(space(18))

        layout.addView(section("GAME VERSION"), matchWrap())
        version = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1.16.5", "1.18.2", "1.19.4", "1.20.1", "1.21.1", "1.21.11"))
        }
        layout.addView(version, matchWrap())
        layout.addView(space(18))

        layout.addView(section("MEMORY SETTINGS"), matchWrap())
        ramLabel = label("Suggested memory: 768 MB")
        layout.addView(ramLabel, matchWrap())
        val ram = SeekBar(this).apply { max = 1536; progress = 768 }
        ram.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                ramLabel.text = "Suggested memory: ${((p / 128) * 128).coerceAtLeast(512)} MB"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        layout.addView(ram, matchWrap())
        layout.addView(label("3 GB phone tip: start at 768–1024 MB and close background apps."), matchWrap())
        layout.addView(space(18))

        layout.addView(section("PERFORMANCE PRESET"), matchWrap())
        val preset = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Low-end phone (recommended)", "Balanced", "Visual quality"))
        }
        layout.addView(preset, matchWrap())
        layout.addView(space(20))

        val launch = Button(this).apply {
            text = "LAUNCH MINECRAFT"
            setTextColor(Color.BLACK)
            setBackgroundColor(cyan)
            setOnClickListener {
                status.text = "Game engine not integrated yet. See README for build and next steps."
            }
        }
        layout.addView(launch, matchWrap())
        layout.addView(space(12))
        status = label("Status: UI ready • Game engine: not integrated")
        status.gravity = Gravity.CENTER
        status.setPadding(12, 16, 12, 16)
        status.setBackgroundColor(panel)
        layout.addView(status, matchWrap())
        layout.addView(space(18))
        layout.addView(label("Starter app only. Minecraft game files and runtime are not included."), matchWrap())
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(Color.rgb(225, 233, 245))
        setPadding(0, 8, 0, 8)
    }
    private fun section(s: String) = TextView(this).apply {
        text = s
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(cyan)
        setPadding(0, 8, 0, 4)
    }
    private fun space(h: Int) = TextView(this).apply { height = h }
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
